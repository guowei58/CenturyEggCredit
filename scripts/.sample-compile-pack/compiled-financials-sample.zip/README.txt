Century Egg Credit — compiled financial statements sample pack
Generated: 2026-06-14T19:56:13.117Z
Tickers: MSFT, BRK.B, HD, V, META, AAPL, UNH, AMZN, JPM, PEP, TXN, AVGO, SPGI, INTU, TMO, MCD, AMGN, QCOM, DECK, EMR, ETN, BIO, GNRC, MANH, SPSC, PDFS, ZD, ATEN, MODG, CABO

Each workbook is consolidated IS/BS/CF from SEC as-presented face extracts.

MSFT: compileOk=false saved=25 (no output) ERROR: 564590-19-012709.xlsx �� 2 concepts (html:acquisition-of-companies-net-of-cash-acquired-and-purchases-of-intangible-and-other-assets, html:other-net) summed to 135.0
2026-06-14 09:49:31,431 [INFO] consolidator: SUM-WITHIN-FILE: cash_flow/us-gaap:ProceedsFromPaymentsForOtherFinancingActivities/1Q23 in MSFT_SEC-XBRL-financials_as-presented_10-Q_2023-04-25_0000950170-23-014423.xlsx �� 2 concepts (html:acquisition-of-companies-net-of-cash-acquired-and-purchases-of-intangible-and-other-assets, html:
BRK.B: compileOk=true saved=30 BRK.B_compiled_financials.xlsx
HD: compileOk=true saved=30 HD_compiled_financials.xlsx
V: compileOk=true saved=30 V_compiled_financials.xlsx
META: compileOk=true saved=30 META_compiled_financials.xlsx
AAPL: compileOk=true saved=30 AAPL_compiled_financials.xlsx
UNH: compileOk=true saved=30 UNH_compiled_financials.xlsx
AMZN: compileOk=true saved=30 AMZN_compiled_financials.xlsx
JPM: compileOk=true saved=30 JPM_compiled_financials.xlsx
PEP: compileOk=true saved=30 PEP_compiled_financials.xlsx
TXN: compileOk=true saved=30 TXN_compiled_financials.xlsx
AVGO: compileOk=true saved=30 AVGO_compiled_financials.xlsx
SPGI: compileOk=true saved=30 SPGI_compiled_financials.xlsx
INTU: compileOk=true saved=30 INTU_compiled_financials.xlsx
TMO: compileOk=true saved=30 TMO_compiled_financials.xlsx
MCD: compileOk=true saved=30 MCD_compiled_financials.xlsx
AMGN: compileOk=true saved=30 AMGN_compiled_financials.xlsx
QCOM: compileOk=true saved=30 QCOM_compiled_financials.xlsx
DECK: compileOk=true saved=30 DECK_compiled_financials.xlsx
EMR: compileOk=true saved=30 EMR_compiled_financials.xlsx
ETN: compileOk=true saved=30 ETN_compiled_financials.xlsx
BIO: compileOk=true saved=30 BIO_compiled_financials.xlsx
GNRC: compileOk=true saved=30 GNRC_compiled_financials.xlsx
MANH: compileOk=true saved=30 MANH_compiled_financials.xlsx
SPSC: compileOk=true saved=30 SPSC_compiled_financials.xlsx
PDFS: compileOk=true saved=30 PDFS_compiled_financials.xlsx
ZD: compileOk=true saved=30 ZD_compiled_financials.xlsx
ATEN: compileOk=true saved=30 ATEN_compiled_financials.xlsx
MODG: compileOk=false saved=0 (no output) ERROR: ticker not in SEC cache
CABO: compileOk=true saved=30 CABO_compiled_financials.xlsx