Century Egg Credit — compiled financial statements sample pack
Generated: 2026-06-14T00:39:17.322Z
Tickers: MSFT, BRK.B, PEP, TXN, GNRC

Each workbook is consolidated IS/BS/CF from SEC as-presented face extracts.

MSFT: compileOk=true saved=30 MSFT_compiled_financials.xlsx
BRK.B: compileOk=true saved=30 BRK.B_compiled_financials.xlsx
PEP: compileOk=true saved=30 PEP_compiled_financials.xlsx
TXN: compileOk=true saved=30 TXN_compiled_financials.xlsx
GNRC: compileOk=true saved=30 GNRC_compiled_financials.xlsx